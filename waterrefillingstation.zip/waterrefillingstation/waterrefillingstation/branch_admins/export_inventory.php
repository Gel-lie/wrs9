<?php
require_once '../includes/functions.php';

// Check if user is logged in and is a branch admin
if (!isLoggedIn() || !hasRole('branch_admin')) {
    header("Location: /login.php");
    exit();
}

require_once '../includes/db.php';

// Get user's information
$user = getUserInfo($_SESSION['user_id']);

// Get report parameters
$type = isset($_GET['type']) && $_GET['type'] === 'low' ? 'low' : 'all';
$format = isset($_GET['format']) && $_GET['format'] === 'csv' ? 'csv' : 'pdf';

// Build query based on report type
$query = "
    SELECT p.product_name, p.category, p.price,
           i.quantity, i.low_stock_threshold, i.last_updated,
           CASE 
               WHEN i.quantity <= i.low_stock_threshold THEN 1 
               ELSE 0 
           END as is_low_stock
    FROM inventory i
    JOIN products p ON i.product_id = p.product_id
    WHERE i.branch_id = ? AND p.status = 'active'
";

if ($type === 'low') {
    $query .= " AND i.quantity <= i.low_stock_threshold";
}

$query .= " ORDER BY p.category, p.product_name";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user['branch_id']);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Log activity
logActivity($user['user_id'], 'export_inventory', "Exported $type inventory report in $format format");

if ($format === 'csv') {
    // Generate CSV
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="inventory_report_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // Add headers
    fputcsv($output, [
        'Product Name',
        'Category',
        'Price',
        'Current Stock',
        'Low Stock Threshold',
        'Status',
        'Last Updated'
    ]);
    
    // Add data
    foreach ($items as $item) {
        fputcsv($output, [
            $item['product_name'],
            ucfirst($item['category']),
            number_format($item['price'], 2),
            $item['quantity'],
            $item['low_stock_threshold'],
            $item['is_low_stock'] ? 'Low Stock' : 'In Stock',
            date('M d, Y h:i A', strtotime($item['last_updated']))
        ]);
    }
    
    fclose($output);
    
} else {
    // Generate PDF using TCPDF
    require_once '../vendor/tcpdf/tcpdf.php';
    
    class MYPDF extends TCPDF {
        public function Header() {
            $this->SetFont('helvetica', 'B', 15);
            $this->Cell(0, 15, 'Inventory Report', 0, false, 'C', 0, '', 0, false, 'M', 'M');
        }
        
        public function Footer() {
            $this->SetY(-15);
            $this->SetFont('helvetica', 'I', 8);
            $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
        }
    }
    
    // Create new PDF document
    $pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    
    // Set document information
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor($user['name']);
    $pdf->SetTitle('Inventory Report');
    
    // Set default header data
    $pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);
    
    // Set header and footer fonts
    $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
    $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
    
    // Set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
    
    // Set margins
    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
    $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
    
    // Set auto page breaks
    $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
    
    // Add a page
    $pdf->AddPage();
    
    // Set font
    $pdf->SetFont('helvetica', '', 10);
    
    // Add report info
    $pdf->Cell(0, 10, 'Branch: ' . $user['branch_name'], 0, 1);
    $pdf->Cell(0, 10, 'Report Type: ' . ($type === 'low' ? 'Low Stock Items' : 'All Items'), 0, 1);
    $pdf->Cell(0, 10, 'Generated on: ' . date('F d, Y h:i A'), 0, 1);
    
    $pdf->Ln(10);
    
    // Column headers
    $headers = array('Product', 'Category', 'Price', 'Stock', 'Threshold', 'Status', 'Last Updated');
    $widths = array(50, 30, 25, 20, 20, 25, 40);
    
    // Colors for header row
    $pdf->SetFillColor(52, 58, 64);
    $pdf->SetTextColor(255);
    $pdf->SetFont('', 'B');
    
    // Print header row
    for($i = 0; $i < count($headers); $i++) {
        $pdf->Cell($widths[$i], 7, $headers[$i], 1, 0, 'C', true);
    }
    $pdf->Ln();
    
    // Reset text color and font
    $pdf->SetTextColor(0);
    $pdf->SetFont('');
    
    // Data rows
    $fill = false;
    foreach($items as $item) {
        // Set background color for low stock items
        if ($item['is_low_stock']) {
            $pdf->SetFillColor(255, 243, 205);
            $fill = true;
        } else {
            $fill = false;
        }
        
        $pdf->Cell($widths[0], 6, $item['product_name'], 1, 0, 'L', $fill);
        $pdf->Cell($widths[1], 6, ucfirst($item['category']), 1, 0, 'L', $fill);
        $pdf->Cell($widths[2], 6, number_format($item['price'], 2), 1, 0, 'R', $fill);
        $pdf->Cell($widths[3], 6, $item['quantity'], 1, 0, 'C', $fill);
        $pdf->Cell($widths[4], 6, $item['low_stock_threshold'], 1, 0, 'C', $fill);
        $pdf->Cell($widths[5], 6, $item['is_low_stock'] ? 'Low Stock' : 'In Stock', 1, 0, 'C', $fill);
        $pdf->Cell($widths[6], 6, date('M d, Y', strtotime($item['last_updated'])), 1, 0, 'C', $fill);
        $pdf->Ln();
    }
    
    // Add summary
    $pdf->Ln(10);
    $pdf->SetFont('', 'B');
    $pdf->Cell(0, 10, 'Summary:', 0, 1);
    $pdf->SetFont('');
    
    $total_items = count($items);
    $low_stock_items = array_sum(array_column($items, 'is_low_stock'));
    $total_value = array_sum(array_map(function($item) {
        return $item['price'] * $item['quantity'];
    }, $items));
    
    $pdf->Cell(0, 6, "Total Items: $total_items", 0, 1);
    $pdf->Cell(0, 6, "Low Stock Items: $low_stock_items", 0, 1);
    $pdf->Cell(0, 6, "Total Inventory Value: " . formatCurrency($total_value), 0, 1);
    
    // Output the PDF
    $pdf->Output('inventory_report_' . date('Y-m-d') . '.pdf', 'D');
}
?> 