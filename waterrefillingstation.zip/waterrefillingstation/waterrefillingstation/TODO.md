# TODO: Fix Receipt in Refill Request

## Tasks
- [x] Edit customers/refill_request.php to add redirect to order_confirmation.php?id=$order_id after successful order creation
- [x] Create customers/refill_receipt.php for refill-specific receipt
- [x] Edit customers/refill_request.php to redirect to refill_receipt.php?id=$order_id
