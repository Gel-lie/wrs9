<?php
require_once 'includes/functions.php';

// Redirect if already logged in
if (isLoggedIn()) {
    $role = $_SESSION['role'];
    $baseURL = rtrim(SITE_URL, '/'); // Get the base URL from config
    
    $redirect = match($role) {
        'customer' => $baseURL . '/customers/dashboard.php',
        'branch_admin' => $baseURL . '/branch_admins/dashboard.php',
        'super_admin' => $baseURL . '/super_admin/dashboard.php',
        default => $baseURL . '/'
    };
    header("Location: $redirect");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    
    if (empty($username) || empty($password)) {
        $error = 'Please fill in all fields';
    } else {
        require_once 'includes/db.php';
        
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND status = 'active'");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                // Set session variables
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['name'] = $user['name'];
                if ($user['branch_id']) {
                    $_SESSION['branch_id'] = $user['branch_id'];
                }
                
                // Update last login
                $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE user_id = ?");
                $stmt->bind_param("i", $user['user_id']);
                $stmt->execute();
                
                // Log activity
                logActivity($user['user_id'], 'login', 'User logged in');
                
                // Check loyalty rewards for customers
                if ($user['role'] === 'customer') {
                    checkCustomerLoyaltyRewards($user['user_id']);
                }
                
                // Redirect based on role
                $baseURL = rtrim(SITE_URL, '/');
                $redirect = match($user['role']) {
                    'customer' => $baseURL . '/customers/dashboard.php',
                    'branch_admin' => $baseURL . '/branch_admins/dashboard.php',
                    'super_admin' => $baseURL . '/super_admin/dashboard.php',
                    default => $baseURL . '/'
                };
                header("Location: $redirect");
                exit();
            } else {
                $error = 'Invalid password';
            }
        } else {
            $error = 'Username not found or account is inactive';
        }
    }
}

require_once 'includes/header.php';
?>

<style>
/* Hide navbar and container for login page */
.navbar, .container.mb-4 {
    display: none !important;
}

/* Remove any default margins/padding from body and html */
html, body {
    margin: 0;
    padding: 0;
    height: 100%;
    overflow: hidden; /* Prevent scrolling */
}

.login-container {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #1e3c72 0%, #2a5298 50%, #3a7bd5 100%);
    padding: 20px;
}

.login-card {
    width: 100%;
    max-width: 900px;
    border: none;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
}

.login-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 30px 60px rgba(0,0,0,0.2);
}

.login-left {
    background: white;
    padding: 40px;
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.login-right {
    background: url('https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80');
    background-size: cover;
    background-position: center;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px;
    position: relative;
}

.login-right::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, rgba(30, 60, 114, 0.3), rgba(42, 82, 152, 0.3));
    pointer-events: none;
}

.form-floating {
    margin-bottom: 20px;
}

.btn-login {
    background: linear-gradient(135deg, #1e3c72, #2a5298);
    border: none;
    padding: 12px 30px;
    border-radius: 25px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-login:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(30, 60, 114, 0.3);
}

@media (max-width: 768px) {
    .login-container {
        padding: 10px;
    }

    .login-card {
        flex-direction: column;
        max-width: 100%;
    }

    .login-left, .login-right {
        padding: 30px 20px;
    }

    .login-right {
        min-height: 200px;
    }
}

@media (max-width: 480px) {
    .login-left, .login-right {
        padding: 20px 15px;
    }
}
</style>

<div class="login-container">
    <div class="card login-card">
        <div class="row g-0">
            <!-- Login Form -->
            <div class="col-md-6 login-left">
                <div class="text-center mb-4">
                    <h2 class="fw-bold text-dark mb-2">Welcome Back</h2>
                    <p class="text-muted">Sign in to your account</p>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <form method="post" action="login.php">
                    <div class="form-floating">
                        <input type="text" class="form-control" id="username" name="username"
                               placeholder="Username" required>
                        <label for="username">
                            <i class="fas fa-user me-2"></i>Username
                        </label>
                    </div>

                    <div class="form-floating">
                        <input type="password" class="form-control" id="password" name="password"
                               placeholder="Password" required>
                        <label for="password">
                            <i class="fas fa-lock me-2"></i>Password
                        </label>
                    </div>

                    <div class="d-grid mb-3">
                        <button type="submit" class="btn btn-primary btn-login">
                            <i class="fas fa-sign-in-alt me-2"></i>Login
                        </button>
                    </div>
                </form>

                <div class="text-center">
                    <p class="mb-0 text-muted">Don't have an account?
                        <a href="register.php" class="text-decoration-none fw-semibold">Register here</a>
                    </p>
                </div>
            </div>

            <!-- Image Section -->
            <div class="col-md-6 login-right">
                <!-- Water ripple image only -->
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?> 